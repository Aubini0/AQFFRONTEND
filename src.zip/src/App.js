import "./styles/App.scss";
import Routers from "./routes/Routers";

function App() {
  return (
    <div className="App">
      <Routers />
    </div>
  );
}

export default App;
